--Create Product Dimention 
CREATE TABLE dim_product
  (
     product_key         INT NOT NULL IDENTITY(1, 1), --> surrogate key
     product_id          INT NOT NULL,                --> business key
     name				 NVARCHAR(50),
     product_subcategory NVARCHAR(50),
     product_category    NVARCHAR(50),
	 Product_description NVARCHAR(400),
     color               NVARCHAR(15),
     model_name          NVARCHAR(50),
     reorder_point       SMALLINT,
     standard_cost       MONEY,
     source_system_code  TINYINT NOT NULL,
     start_date          DATETIME NOT NULL DEFAULT (Getdate()),
     end_date            DATETIME,
     is_current          TINYINT NOT NULL DEFAULT (1),
     CONSTRAINT pk_dim_product PRIMARY KEY (product_key)
  );

-- Insert unknown record
SET IDENTITY_INSERT dim_product ON

INSERT INTO dim_product
            (product_key,
             product_id,
             name,
             product_subcategory,
             product_category,
			 Product_description,
             color,
             model_name,
             reorder_point,
             standard_cost,
             source_system_code,
             start_date,
             end_date,
             is_current)
VALUES      (0,
             0,
             'Unknown',
             'Unknown',
             'Unknown',
             'Unknown',
             'Unknown',
             'Unknown',
             0,
             0,
             0,
             '1900-01-01',
             NULL,
             1)

SET IDENTITY_INSERT dim_product OFF

-- create foreign key
IF EXISTS (SELECT *
           FROM   sys.tables
           WHERE  NAME = 'fact_sales')
  ALTER TABLE fact_sales
    ADD CONSTRAINT fk_fact_sales_dim_product FOREIGN KEY (product_key)
    REFERENCES
    dim_product(product_key);

-- create indexes

CREATE INDEX dim_product_product_id
  ON dim_product(product_id);


CREATE INDEX dim_prodct_product_category
  ON dim_product(product_category); 

  select * from dim_product