USE master
go

IF Db_id('Adventure_Works_DW_2022') IS NOT NULL
  DROP DATABASE Adventure_Works_DW_2022;

CREATE DATABASE Adventure_Works_DW_2022
go 
