use [AdventureWorks2022]
go

select 
	h.SalesOrderID as order_id,
	d.SalesOrderDetailID ,
	d.ProductID ,
	h.CustomerID ,
	h.TerritoryID,
	h.ShipMethodID,
	convert(date , h.OrderDate) as order_date,
	d.OrderQty,
	d.UnitPrice,
	h.Freight
from [Sales].[SalesOrderHeader] h
join [Sales].[SalesOrderDetail] d
on h.SalesOrderID = d.SalesOrderID
where OnlineOrderFlag = 1
order by  h.SalesOrderID, d.SalesOrderDetailID








