CREATE TABLE dim_ship_method
  (
     ship_method_key      INT NOT NULL IDENTITY(1, 1),
     ship_method_id      INT NOT NULL,
     name     NVARCHAR(60),
     source_system_code TINYINT NOT NULL,
     start_date         DATETIME NOT NULL DEFAULT (Getdate()),
     end_date           DATETIME,
     is_current         TINYINT NOT NULL DEFAULT (1),
     CONSTRAINT pk_dim_ship_method PRIMARY KEY  (ship_method_key)
  );

-- Insert unknown record
SET IDENTITY_INSERT dim_ship_method ON

INSERT INTO dim_ship_method
            (ship_method_key,
             ship_method_id,
             name,
             source_system_code,
             start_date,
             end_date,
             is_current)
VALUES     (0,
            0,
            'Unknown',
            0,
            '1900-01-01',
            NULL,
            1)

SET IDENTITY_INSERT dim_ship_method OFF

-- create foreign key
IF EXISTS (SELECT *
           FROM   sys.tables
           WHERE  NAME = 'fact_sales')
  ALTER TABLE fact_sales
    ADD CONSTRAINT fk_fact_sales_dim_territory FOREIGN KEY (territory_key)
    REFERENCES dim_territory(territory_key);

-- create indexes

CREATE INDEX dim_ship_method_ship_method_id
  ON dim_ship_method(ship_method_id); 