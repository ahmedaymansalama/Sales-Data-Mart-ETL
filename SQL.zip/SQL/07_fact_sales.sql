
CREATE TABLE fact_sales
  (
	 order_id INT NOT NULL,
     order_detail_id INT NOT NULL,
     product_key    INT NOT NULL,
     customer_key   INT NOT NULL,
     territory_key  INT NOT NULL,
	 ship_method_key INT NOT NULL,
     order_date_key INT NOT NULL,
     quantity       INT,
     unit_price     MONEY,
     unit_cost      MONEY,
     tax_amount     MONEY,
     freight        MONEY,
     extended_sales MONEY,
     extened_cost   MONEY,
     created_at     DATETIME NOT NULL DEFAULT(Getdate()),
     CONSTRAINT pk_fact_sales PRIMARY KEY (order_id, order_detail_id),
     CONSTRAINT fk_fact_sales_dim_product FOREIGN KEY (product_key) REFERENCES
     dim_product(product_key),
     CONSTRAINT fk_fact_sales_dim_customer FOREIGN KEY (customer_key) REFERENCES
     dim_customer(customer_key),
     CONSTRAINT fk_fact_sales_dim_territory FOREIGN KEY (territory_key)
     REFERENCES dim_territory(territory_key),
     CONSTRAINT fk_fact_sales_dim_date FOREIGN KEY (order_date_key) REFERENCES
     dim_date(date_key),
	 CONSTRAINT fk_fact_sales_dim_ship_method FOREIGN KEY (ship_method_key) REFERENCES
     dim_ship_method(ship_method_key)
  );

-- Create Indexes

CREATE INDEX fact_sales_dim_product
  ON fact_sales(product_key);


CREATE INDEX fact_sales_dim_customer
  ON fact_sales(customer_key);


CREATE INDEX fact_sales_dim_territory
  ON fact_sales(territory_key);


CREATE INDEX fact_sales_dim_ship_method
  ON fact_sales(ship_method_key); 


CREATE INDEX fact_sales_dim_date
  ON fact_sales(order_date_key); 
